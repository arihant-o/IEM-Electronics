# INA237
This implements library for Texas Instruments INA237 power monitor sensor IC.
