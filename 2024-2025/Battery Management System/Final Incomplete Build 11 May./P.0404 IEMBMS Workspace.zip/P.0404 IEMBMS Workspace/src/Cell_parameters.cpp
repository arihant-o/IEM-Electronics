#include "Cell_parameters.hpp"

uint8_t Cell::bypassTemperatureSetPoint;
uint16_t Cell::bypassThreshold_mV;
float Cell::calibration;
uint8_t Cell::bypassTemperatureHysteresis;

const int16_t Cell::safetyTemperatureCutoff = 80;                                                  // Maximum allowable temperature
bool Cell::overtemperature = false;

