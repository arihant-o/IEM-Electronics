/// @brief Core libraries for Arduino Framework

#include <Arduino.h>
#include <SPI.h>
#include <Wire.h>

/// @brief User-defined libraries for the project

#include "GPIO_pin_definitions.hpp"                                                                // GPIO pin definitions
#include "MAX14920_byte_definitions.hpp"                                                           // Configuration bit defintions for MAX14920
#include "Cell_parameters.hpp" 
#include "NTC_lookup.hpp"

/// @brief Imported libraries for the project

#include "Mcp320x.h"                                                                               // Support Library for MCP3208 SPI ADC
#include "INA237.h"                                                                                // Support Library for INA237 Current Sensor 
#include "STM32_CAN.h"                                                                             // Support Library for Basic CAN bus implementation

/// @brief Extra supporting libraries for the project

#include "stm32l4xx_hal.h"
#include "IWatchdog.h"                                                                             // Auto software failure repair by issuing a system reset

/// @brief Supporting functions for acquiring STM32 internal temperature
#define TEMP30_CAL_ADDR ((uint16_t*) ((uint32_t) 0x1FFF75A8))  // TS_CAL1
#define TEMP130_CAL_ADDR ((uint16_t*) ((uint32_t) 0x1FFF75CA)) // TS_CAL2
#define VREFINT_CAL_ADDR ((uint16_t*) ((uint32_t) 0x1FFF75AA)) // VREFINT_CAL
#define VREFINT_CAL ((uint16_t) (*VREFINT_CAL_ADDR))

ADC_HandleTypeDef hadc1;

/// @attention Defines for ISR
/// Comment out the following lines to disable the corresponding test

//#define TEST_DEBUG_LED                                                                           // Debug LED Blinking Test
//#define TEST_HS_PTC                                                                              // High-side PTC Protection Test
//#define ERROR_FN
#define MAX_DEBUG

#define HAL_ADC_DEBUG                                                                              // For debugging STM32 internal temperature sensor and ADC

/// @brief Global Variables

HardwareSerial Serial1(D0, D1);                                                                    // Standard Serial does not allow A3 (MCP_CS) to be used

INA237 ina237(&Wire, 0x40);                                                                        // INA237 Object for current sensing

STM32_CAN Can1(CAN1, DEF);                                                                         // Default CAN TX and RX pins on STM32L432KC (D2 and D10, respectively)

const int MCP_SPI_CLK = 1600000;                                                                   // SPI Clock Frequency 1.6 MHz for MCP3208
MCP3208 mcp3208_adc(4500, MCP_CS);                                                                 // MCP3208 Object with 4.5V reference voltage
SPISettings mcpSettings(MCP_SPI_CLK, MSBFIRST, SPI_MODE0);                                         // SPI Settings for MCP3208

const auto MAX14920_SPI_settings = SPISettings(4000000, MSBFIRST, SPI_MODE0);                      // SPI settings for MAX14920 - ensure SCLK does not exceed 4.5 MHz due to minimum period

//const int battery_cells_Series = 7;                                                                // Number of cells in series - 10 -> should automatically detect number of cells, from prior testing
const int batteryMaxCurrent = 23.75;                                                               // Maximum discharge current of battery pack in Amps
uint8_t num_Active_cells = 0;                                                                    // Number of cells actually connected to MAX chip (3/4 to 12)

uint16_t cellBalancing = 0;                                                                        // Bitmap of which cells are balancing (maps to MAX chip register)
CellData cellData{};                                                                               // Global variable to hold cell level data as it is collected

const int MAX_settlingTime = 50;

//============================================================================================================================================================================
/// @attention HAL Configuration (STM32)

void ADC_Init(void) {
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);                                   // Enable internal voltage regulator

  hadc1.Instance = ADC1;                                                                           // Enable ADC voltage regulator
  HAL_ADC_DeInit(&hadc1);
  
                                                                                                   // Configure ADC
  hadc1.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.ScanConvMode = ADC_SCAN_ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.NbrOfConversion = 2;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.NbrOfDiscConversion = 1;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc1.Init.OversamplingMode = DISABLE;
  
  HAL_ADC_Init(&hadc1);
  __HAL_RCC_ADC_CLK_ENABLE();                                                                      // Enable internal voltage reference and temperature sensor
  ADC_Enable(&hadc1);
  
  if (HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED) != HAL_OK) {                           // Calibrate ADC
    #ifdef HAL_ADC_DEBUG
      Serial1.println("ADC Calibration Error");
    #endif
  }

  if (HAL_ADC_Start(&hadc1) != HAL_OK) {                                                           // Enable ADC
    #ifdef HAL_ADC_DEBUG
      Serial1.println("ADC Start Error");
    #endif
  }
}

//============================================================================================================================================================================
/// @attention Miscellaneous shortcut functions


//============================================================================================================================================================================
/// @attention Debug LED Functions

void DEBUG_led_on() {
  digitalWrite(PROG1, HIGH);                                                                       // Turn on the Debug LED
}

void DEBUG_led_off() {
  digitalWrite(PROG1, LOW);                                                                        // Turn off the Debug LED
}

void DEBUG_led_toggle() {
  digitalWrite(PROG1, !digitalRead(PROG1));                                                        // Toggle the Debug LED
}

void DEBUG_led_ISR() {
  #ifdef TEST_DEBUG_LED
    DEBUG_led_toggle();                                                                            // Toggle the Debug LED
  #endif
}

//============================================================================================================================================================================
/// @attention High-Side Switch Protection Functions

void HS_Protection_on() {
  digitalWrite(PROTECT_SIGNAL, LOW);                                                               // Turn on the high-side switch
}

void HS_Protection_off() {
  digitalWrite(PROTECT_SIGNAL, HIGH);                                                              // Turn off the high-side switch
}

void HS_Protection_toggle() {
  digitalWrite(PROTECT_SIGNAL, !digitalRead(PROTECT_SIGNAL));                                      // Toggle the high-side switch
}

void HS_Protection_ISR() {
  #ifdef TEST_HS_PTC
    HS_Protection_toggle();                                                                        // Toggle the high-side switch
  #endif
}

//============================================================================================================================================================================
/// @attention INA237 Current Sensor Functions 

void INA237_setup() {
  /// @todo Change INA237 parameters accordingly following testing

  /// @todo Check what reset does, remove if unnecessary

  // Reset bit:
  // Set to 1 generates a system reset that is the same as a power-on reset. The bit is self-clearing.
  // Refer to page 21 of the datasheet for more information
  ina237.reset();

  // INA237 Configuration
  ina237.configADC(INA237_DEFAULT_ADC_CONFIG);
  // CONT_TEMP_VBUS_VSHUNT, CT_1052US, CT_1052US, CT_1052US, AVG_1
  // 0xF, 0x5, 0x5, 0x5, 0x0

  // ADC_CONFIG bits:
  // 15-12 [MODE]: user can set the MODE bits for continuous or triggered mode on bus voltage, shunt voltage or temperature measurement.
  // Fh: Continuous bus voltage, shunt voltage and temperature measurement
  // 11-9 [VBUSCT]: sets the conversion time of the bus voltage measurement
  // 5h: 1052us
  // 8-6 [VSHCT]: sets the conversion time of the shunt voltage measurement
  // 5h: 1052us
  // 5-3 [VTCT]: sets the conversion time of the temperature measurement
  // 5h: 1052us
  // 2-0 [AVG]: Selects ADC sample averaging count. The averaging setting applies to all active inputs.
  // When >0h, the output registers are updated after the averaging has completed
  // 0h: 1 sample

  // Refer to page 22-23 of the datasheet for more information

  // INA237 Calibration
  // Resolution, Max Current, Rounding
  ina237.calibrate(0.0068, batteryMaxCurrent, true);

  // Note the ALERT pin is not used on the PCB, so the configuration is not necessary
  // However, the configuration is provided for reference

  // ina237_alrt_config_t alrt_config;
  // INA237 Alert Configuration Bits
  // 15 [ALATCH]: Alert Pin reset to idle state when fault cleared (0) or latched until DIAG_ALRT register read (1)
  // alrt_config.alatch = 0;
  // 14 [CNRV]: Alert Pin asserted when conversion cycle is completed - 0: disabled, 1: enabled
  // alrt_config.cnvr = 0;
  // 13 [SLOWALERT]: Alert Pin asserted when averaged conversion value is completed - 0: disabled, 1: enabled
  // alrt_config.slowalert = 0;
  // 12 [APOL]: Sets Alert Pin polarity (normal open-drain or inverted) - 0: normal, 1: inverted
  // alrt_config.apol = 0;

  // Other bits of the DIAG_ALRT register are read for fault conditions, refer to pages 24-25 of the datasheet for more information
  
  // ina237.configAlert(alrt_config);

  // Set ADC differential range
  // 0x0: 163.84mV
  // 0x1: 40.96mV
  ina237.setADCRange(0x0);

  // Set conversion delay
  // Bits 13-6 of the CONFIG register
  // 0x0: 0s
  // 0x1: 2ms
  // 0xff: 510ms
  ina237.setConversionDelay(0x1);

  /// @todo Check if the following voltage thresholds are in Volts
  
  // Set shunt threshold voltages (remove if unnecessary)
  ina237.setShuntOvervoltageTreshold(0.16);
  ina237.setShuntUndervoltageTreshold(-0.16);

  // Set bus threshold voltages (remove if unnecessary)
  ina237.setBusOvervoltageTreshold(50);
  ina237.setBusUndervoltageTreshold(10);

  // Set Temperature High Threshold (remove if unnecessary)
  /// @todo Check if this threshold is in Celcius and corresponds to external IC temperature
  ina237.setTempOverlimitTreshold(55); 

  // Set Power Over Limit Threshold (remove if unnecessary)
  /// @todo Check if this threshold is in Watts
  ina237.setPowerOverlimitTreshold(250);

  // Set Current thresholds
  ina237.setUnderCurrentTreshold(0.1); // Remove if necessary
  ina237.setOverCurrentTreshold(batteryMaxCurrent); 

  // The lines above (105-123) may be commented out since the ALERT pin is not connected on the PCB
}

void INA237_allData() {

  Serial1.println("Bus Voltage: ");
  Serial1.println(ina237.getBusVoltage());
  Serial1.println("Shunt Voltage: ");
  Serial1.println(ina237.getShuntVoltage());
  Serial1.println("Current: ");
  Serial1.println(ina237.getCurrent());
  Serial1.println("Power: ");
  Serial1.println(ina237.getPower());
  Serial1.println("Temperature: ");
  Serial1.println(ina237.getTemp());

  delay(500);
}

float INA237_Voltage_Bus() {return ina237.getBusVoltage();}

float INA237_Voltage_shunt() {return ina237.getShuntVoltage();}

float INA237_Current() {return ina237.getCurrent();}

float INA237_Power_Electrical() {return ina237.getPower();}                                        // Product of bus voltage and current

float INA237_Temperature() {return ina237.getTemp();}

void INA237_currentProtection_test(float current) {
  if (INA237_Current() > current) {
    Serial1.println("Current Fault!\n");

    Serial1.print("Bus current: ");
    Serial1.print(INA237_Current());
    Serial1.print(" Current Limit: ");
    Serial1.println(current);

    HS_Protection_off();
    for (int i=0; i<10; i++) {
      DEBUG_led_toggle();
      delay(500);
    }
    HS_Protection_on();
  }

  else {
    Serial1.print("Bus current: ");
    Serial1.println(INA237_Current());
  }
}

//============================================================================================================================================================================
/// @attention MCP3208 ADC Functions

void MCP3208_test_all() {
  /// @section Tests all 8 channels of the MCP3208 ADC. 
  // Note some channels are already connected to other devices e.g. CH3 for AOUT for MAX14920, CH0,1,2 & 8 for NTC Thermistors
  /// @todo Recommend adding a delay between function calls to prevent overloading serial output

  // Check SPI devices before performing readings
  digitalWrite(MAX_CS, HIGH);
  digitalWrite(MCP_CS, LOW);                                                                       // Although done in library, double check CS state

  digitalWrite(TH_EN, HIGH);                                                                       // Optional temperature reading: LOW to enable, HIGH to disable

  SPI.beginTransaction(mcpSettings);                                                               // Begin SPI transaction for MCP3208

  Serial1.println("Reading...");
  Serial1.println("ADC 0, CH0 (external NTC 1)");
  Serial1.println(mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_0)));             // Read ADC channel 0
  Serial1.println("ADC 0, CH1 (external NTC 2)");
  Serial1.println(mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_1)));             // Read ADC channel 1
  Serial1.println("ADC 0, CH2 (external NTC 3)");
  Serial1.println(mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_2)));             // Read ADC channel 2
  Serial1.println("ADC 0, CH3 (MAX14920 AOUT)");
  Serial1.println(mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_3)));             // Read ADC channel 3
  Serial1.println("ADC 0, CH4 (NTC VDD [pmos drain])");
  Serial1.println(mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_4)));             // Read ADC channel 4
  Serial1.println("ADC 0, CH5");
  Serial1.println(mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_5)));             // Read ADC channel 5
  Serial1.println("ADC 0, CH6");
  Serial1.println(mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_6)));             // Read ADC channel 6
  Serial1.println("ADC 0, CH7 (built-in NTC)");
  Serial1.println(mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_7)));             // Read ADC channel 7
  Serial1.println("end\n");
  
  SPI.endTransaction();                                                                            // End SPI transaction for MCP3208

  digitalWrite(MAX_CS, HIGH);                                                                      // Afirm the MAX14920 CS pin
  digitalWrite(MCP_CS, HIGH);                                                                      // Restore MCP_CS to original state

  digitalWrite(TH_EN, HIGH);                                                                       // Disable temperature reading via NTC thermistor
}

void MCP3208_test_temp() {
  /// @section Obtain temperature readings using NTCs and MCP3208 ADC
  /// @todo Recommend adding a delay between function calls to prevent overloading serial output

  // Check SPI devices before performing readings
  digitalWrite(MAX_CS, HIGH);
  digitalWrite(MCP_CS, LOW);                                                                       // Although done in library, double check CS state

  digitalWrite(TH_EN, LOW);                                                                        // Allow temperature reading via NTC thermistor

  SPI.beginTransaction(mcpSettings);                                                               // Begin SPI transaction for MCP3208

  Serial1.println("Reading raw NTC resistor divider voltages in mV");
  Serial1.println("ADC 0, CH0 (external NTC 1)");
  Serial1.println(mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_0)));             // Read ADC channel 0
  Serial1.println("ADC 0, CH1 (external NTC 2)");
  Serial1.println(mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_1)));             // Read ADC channel 1
  Serial1.println("ADC 0, CH2 (external NTC 3)");
  Serial1.println(mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_2)));             // Read ADC channel 2
  Serial1.println("ADC 0, CH7 (built-in NTC)");
  Serial1.println(mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_7)));             // Read ADC channel 7
  Serial1.println("VDD: ");
  Serial1.println(mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_4)));
  Serial1.println("end\n");

  SPI.endTransaction();                                                                            // End SPI transaction for MCP3208

  digitalWrite(MAX_CS, HIGH);                                                                      // Affirm the MAX14920 CS pin
  digitalWrite(MCP_CS, HIGH);                                                                      // Restore MCP_CS to original state
  digitalWrite(TH_EN, HIGH);                                                                       // Disable temperature reading via NTC thermistor
}

//============================================================================================================================================================================
/// @attention MAX14920 Functions

uint32_t SPI_24BitTransfer(uint8_t byte1, uint8_t byte2, uint8_t byte3) {
  /// @section combines three separate bytes into a single 24 bit data type for SPI transactions with the MAX14920

  uint32_t data;

  data = SPI.transfer(byte1);
  data <<= 8;

  data |= SPI.transfer(byte2);
  data <<= 8;

  data |= SPI.transfer(byte3);

  // Returns a 24 bit MISO command for MAX14920
  return data;
}

uint32_t MAX14920_SPI_Command(uint8_t byte1, uint8_t byte2, uint8_t byte3) {
  /// @section Send a 24 bit SPI command to MAX14920
  /// @param byte1, byte2, byte3
  /// @return 24 bit SPI MISO command

  /// @details Tell AFE to switch AOUT channel to the measured cell for the ADC to measure

  #ifdef MAX_DEBUG
    Serial1.println("SPI BYTE 1: ");
    Serial1.print(byte1);
    Serial1.println("\nSPI BYTE 2: ");
    Serial1.print(byte2);
    Serial1.println("\nSPI BYTE 3: ");
    Serial1.print(byte3);
    Serial1.println();
  #endif

  SPI.beginTransaction(MAX14920_SPI_settings);
  digitalWrite(MAX_CS, LOW);                                                                       // Pull LOW to enable MAX14920

  auto reply = SPI_24BitTransfer(byte1, byte2, byte3);
  
  digitalWrite(MAX_CS, HIGH);                                                                      // Restore CS state after transaction
  
  SPI.endTransaction();

  #ifdef MAX_DEBUG
    Serial1.print("24-bit reply: 0x");
    Serial1.println(reply, HEX); // This will print the full 24-bit value in hex
    Serial1.print("Bytes: ");
    Serial1.print((reply >> 16) & 0xFF, HEX); Serial1.print(" ");
    Serial1.print((reply >> 8) & 0xFF, HEX); Serial1.print(" ");
    Serial1.println(reply & 0xFF, HEX);
  #endif

  return reply;
}

uint32_t MAX14920_SPI_Command(uint16_t byte1_2, uint8_t byte3) {
  /// @section Sends a 24 bit SPI command to MAX14920
  /// @param byte1_2 <- combines byte 1 and 2 as uint_16 data type
  /// @param byte3 <- standard uint_8t data type
  /// @return 24 bit SPI MISO command

  uint8_t byte1 = (byte1_2 & 0xFF00) >> 8;
  uint8_t byte2 = byte1_2 & 0x00FF;
  return MAX14920_SPI_Command(byte1, byte2, byte3);                                                // Returns another function under the same name
}

uint16_t calculateCellBalanceRequirement(CellData &cd, uint8_t num_cells, int runawaycell_index) {
  /// @section Identifies which BAn signals to enable balancing for specific cells and calculates the bit pattern (passive balancing)
  /// @param cd cell data array
  /// @param num_cells total number of cells
  /// @param runawaycell_index index of cell identified as run away (or -1 if none)
  /// @return bit pattern / SPI command

  uint16_t reply = 0;

  for (auto i=0; i<num_cells; i++) {                                                               // Cycle through each in the battery pack
    Cell &cell = cd.at(i);                                                                         // Get reference to cell object

    if(cell.bypassCheck() == true || runawaycell_index == i) {                                     // Check if bypass is needed, or if a runawat cell is detected
      cell.startBypass();                                                                          // Cell overvoltage threshold - discharge excess through balancing resistor
      reply = reply | (uint16_t)(1U << (11-i));                                                    // Enable balancing bit pattern - enables the MOSFET and balanace resistor
    }
    else {
      cell.stopBypass();                                                                           // Prevent further cell discharge by disabling the balancing resistor
    }
  }
  return reply;                                                                                    // Return SPI command the controls the cell balancing
}

void CalculateCellVoltage_Min_Max(CellData &cd, uint8_t num_cells, uint16_t &lowest_mV, uint16_t &highest_mV, uint16_t &range, uint8_t &highest_index, uint32_t &total) {
  /// @section Calculate various useful metrics about the battery pack
  /// @param cd cell data array
  /// @param num_cells total number of cells
  /// @param lowest_mV (reference) lowest cell voltage (mV)
  /// @param highest_mV (reference) highest cell voltage (mV)
  /// @param range (reference) range between highest and lowest cell voltages (mV)
  /// @param highest_index cell index with the highest voltage
  /// @param total total voltage of all cells (mV)

  lowest_mV = 0xFFFF;
  highest_mV = 0;

  highest_index = -1;                                                                              // Index of cell with highest voltage
  total = 0;

  for (uint8_t i=0; i<num_cells; i++) {                                                            // Determine the highest, lowest and average cell voltages
    const Cell &cell = cd.at(i);                                                                   // Get reference to cell objects
    auto v = cell.getCellVoltage();
    total += v;

    if (v < lowest_mV) {                                                                           // Overwrite the lowest cell voltage value
      lowest_mV = v;
    }
    else if (v > highest_mV) {                                                                     // Overwrite the highest cell voltage value
      highest_mV = v;
      highest_index = i;                                                                           // Overwrite the index of the cell with highest voltage value
    }
  }

  range = highest_mV - lowest_mV;                                                                  // Determine voltage (differential) range
}

uint16_t do_cell_balancing(const int16_t highest_temp) {
  /// @section Determine what cells (if any) need balancing
  /// @param highest_temp is the highest temperature of NTC sensors
  /// @return bit pattern / SPI command for which MOSFETs need enabling

  uint16_t lowest_mV;
  uint16_t highest_mV;
  uint8_t highest_index;
  uint16_t range;
  uint32_t total;

  CalculateCellVoltage_Min_Max(cellData, num_Active_cells, lowest_mV, highest_mV, range, highest_index, total);

  /// @details Check the temperature to ensure safe operation
  if (highest_temp > Cell::get_bypassTemperatureSetPoint() || highest_temp > Cell::getSafetyTemperatureCutoff()) {
    Cell::setOverTemperature(true);                                                                // Temperature over limit so disable all MOSFETs, allow for cooling
    return 0;
  }

  if (Cell::getOverTemperature() == true) {
    /// @details as temperature above threshold, disable balancing until temperature drops below Hysteresis value
    if (highest_temp > Cell::get_bypassTemperatureHysteresis()) {
      return 0;                                                                                    // Still too hot, disable all MOSFETs and allow them to cool
    }
    else {
      Cell::setOverTemperature(false);                                                             // Temperature falls below limit so can allow balancing 
    }
  }

  auto average_mV = (uint16_t)(total / num_Active_cells);                                      // Calculate the average of all the cells
  uint16_t highest_average_diff = highest_mV - average_mV;                                         // Calculate the differential between highest cell voltage and the average

  auto runaway_cell_index = (highest_mV > 3800 && highest_average_diff > 50) ? highest_index : -1;
  /// @attention Determine if the highest "runaway" cell should be balanced:
  /// @details If highest cell above the average cell voltage by X mV, then begin balancing until it no longer is
  /// @details Ensure the cell voltage is abnove a minimum - assume 3800mV for Li-Ion cells
  /// @details This voltage shoulde be below the maximum cell voltage (4.1-4.2V) and high enough to ensure meaningful balancing
  /// @details Set to 3.8V - typically 90% of max voltage. Provides adequate balancing window, better thermal management, improved safety margin and more effect voltage equalisation

  return calculateCellBalanceRequirement(cellData, num_Active_cells, runaway_cell_index);      // Should any cells require balanacing, check if they have gone over the threshold
}

void MAX14920_bufferAmplifierOffsetCalibration() {
  /// @section Calibrates the internal op-amp buffer in the MAX14920

  digitalWrite(MAX_SAMPLE, HIGH);                                                                  // Place MAX14920 into sample mode
  MAX14920_SPI_Command(0, BUFFER_CALIBRATION);                                                     // Calibrate the error from parasitic capacitance charge injection
  delay(8);                                                                                        // Requires 8ms to complete - refer to datasheet
}

uint8_t MAX14920_AFE_status() {
  /// @section Query the MAX14920 AFE and dertermine whether it is ready
  /// @return The number of connected battery cells (maximum of 12)

  uint8_t cellCount;
  uint8_t deviceIsNotReady = 1;
  uint8_t countDown = 20;

  while(countDown > 0) {
    digitalWrite(MAX_SAMPLE, HIGH);                                                                // Sample cell voltages all at the same time
    delay(60);                                                                                     // Wait 60ms for sample capacitors to charge and settle to cell voltage
    digitalWrite(MAX_SAMPLE, LOW);                                                                 // Disable sampling, hold mode
    delayMicroseconds(50);                                                                         // Wait 50µs to settle

    Serial1.print("Cycle: "); Serial1.println(countDown);
    
    auto reply = MAX14920_SPI_Command(0,0, CellTable.at(0));                                       // Switch AOUT channel to zero, all balancing off

    if(reply == 0) {                                                                               // If no reply, chip not connected or enabled
      ErrorFlashes(7);
    }

    deviceIsNotReady = (reply & B00000010) >> 1;                                                   // Checks /RDY bit by masking bit 1 then shift to bit 0 position

    if (((reply & B0000100) >> 3) !=0) {                                                           // Checks UV_VA bit (under 4V7) by masking bit 3 then shift to bit 0 position
      ErrorFlashes(4);
    }

    if (((reply & B00000100) >> 2) !=0) {                                                          // Check UV_VP bit (under 6V) by masking bit 2 then shift to bit 0 position. 
      ErrorFlashes(5);
    }

    if ((reply & B00000001) !=0) {                                                                 // Check OT bit for overtemperature / thermal shitdown of MAX14920
      ErrorFlashes(2);
    }

    /// @section (Re-) Verify the number of valid cells installed to MAX14920
    cellCount = 12;                                                                                // Although MAX14920 has 12S max, using 16S aligns with SPI bits
    uint16_t cells = (reply & 0x00FFF000) >> 8;                                                    // Mask middle 16 bits of 24 bit SPI MISO and inspect each bit (one per cell)

    while(cells) {
      cellCount -= cells & 1;                                                                      // Subtract 1 from cell count for each bit with HIGH state (voltage out of range)
      cells >>= 1;                                                                                 // if bit = 1, means undervoltage for VCV_TH or over 5V - essentially not possible for Li cell to be installed
    }

    if(deviceIsNotReady == 0) {                                                                    // No issues, can exit enclosing loop
      //Serial1.println("MAX14920 ready");
      break;
    }

    //Serial1.println("Not MAX14920 ready");

    delay(250);                                                                                    // Loop again if needed until MAX14920 is ready
    countDown--;
  }

  if(countDown == 0) {                                                                             // If after 5 seconds the MAX14920 is not ready, issue an error signal
    ErrorFlashes(6);
  }

  return cellCount;
}

int16_t MAX14920_AOUT_Measurement() {
  /// @section Specialised version of test MCP3208 general function for CH3 (MAX14920 AOUT)

  /// @details Assume MAX_CS set to HIGH, but affirm MAX_CS HIGH state before changing MCP_CS state
  
  digitalWrite(MAX_CS, HIGH);
  digitalWrite(MCP_CS, LOW);                                                                       // Enable MCP3208 ADC after disabling MAX14920

  SPI.beginTransaction(mcpSettings);
  int16_t val = mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_3));                // MAX14920 AOUT connection
  SPI.endTransaction();

  Serial1.println(val);

  digitalWrite(MAX_CS, HIGH);                                                                      // Afirm the MAX14920 CS pin
  digitalWrite(MCP_CS, HIGH);                                                                      // Restore MCP_CS to original state

  return val;
}

void MAX14920_sampleCellVoltage(uint8_t cellCount, std::array<uint32_t, 16> &rawADC) {
  /// @section Read the cell voltages using MAX14920 to multiplex and level shift cells, while MCP3208 reads the AOUT voltage

  for (int8_t cellid = (cellCount-1); cellid >= 0; cellid--) {
    MAX14920_SPI_Command(0, CellTable.at(cellid));
    delayMicroseconds(MAX_settlingTime);                                                                         // Wait for sampling capacitor AOUT to settle
    rawADC.at(cellid) = MAX14920_AOUT_Measurement();
    
    Serial1.print("Cell voltage: ");
    Serial1.print(rawADC.at(cellid));
    Serial1.print("mV\n");
  }
}

void MAX14920_Test_BAL_output() {
  /// @section tests whether the MAX14920 BAL output pins are operations for all 12 pins

  MAX14920_SPI_Command(0xFFFF, 0x00);                                                              // Set all CB outputs to HIGH
  DEBUG_led_on();
  delay(3000);                                                                                     // 3 second delay
  MAX14920_SPI_Command(0x0000, 0x00);                                                              // Set all CB outputs to LOW
  DEBUG_led_off();
  delay(3000);                                                                                     // 3 second delay

}

void MAX14920_Configuration() {
  /// @section Single function that sets up the MAX14920, ensuring it is ready for general use

  digitalWrite(MAX_EN, LOW);                                                                       // Perform a power reset for MAX14920
  delay(100);
  digitalWrite(MAX_EN, HIGH);
  delay(100);

  MAX14920_bufferAmplifierOffsetCalibration();                                                     // Calibrate the MAX14920 buffer for offset
}



//============================================================================================================================================================================
/// @attention Acquire temperature from various sources

float STM32_read_temperature(void) {
  ADC_ChannelConfTypeDef sConfig = {0};
  uint32_t vrefint_data;
  uint32_t temperature_data;

  /// @details Configure and read temperature sensor
  sConfig.Channel = ADC_CHANNEL_TEMPSENSOR;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_247CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;                                
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  HAL_ADC_ConfigChannel(&hadc1, &sConfig);
  
  HAL_ADC_Start(&hadc1);
  HAL_ADC_PollForConversion(&hadc1, 100);
  temperature_data = HAL_ADC_GetValue(&hadc1);

  /// @details Configure and read VREFINT
  sConfig.Channel = ADC_CHANNEL_VREFINT;
  HAL_ADC_ConfigChannel(&hadc1, &sConfig);
  
  HAL_ADC_Start(&hadc1);
  HAL_ADC_PollForConversion(&hadc1, 100);
  vrefint_data = HAL_ADC_GetValue(&hadc1);

  #ifdef HAL_ADC_DEBUG
    Serial1.print("Raw temp ADC: "); Serial1.println(temperature_data);
    Serial1.print("Raw VREF ADC: "); Serial1.println(vrefint_data);
    Serial1.print("VREF CAL: "); Serial1.println(VREFINT_CAL);
    Serial1.print("TEMP30 CAL: "); Serial1.println(*TEMP30_CAL_ADDR);
    Serial1.print("TEMP130 CAL: "); Serial1.println(*TEMP130_CAL_ADDR);
  #endif

  float temp30 = (float)*TEMP30_CAL_ADDR;
  float temp130 = (float)*TEMP130_CAL_ADDR;

  float vref_ratio = (float)VREFINT_CAL / (float)vrefint_data;
  float compensated_temp = (float)temperature_data * vref_ratio;

  float temperature = (((130.0f - 30.0f) * (compensated_temp - temp30)) / (temp130 - temp30)) + 30.0f;

  #ifdef HAL_ADC_DEBUG
    Serial1.print("VREF ratio: "); Serial1.println(vref_ratio, 3);
    Serial1.print("Compensated temp: "); Serial1.println(compensated_temp, 2);
    Serial1.print("Temp30 value: "); Serial1.println(temp30);
    Serial1.print("Temp130 value: "); Serial1.println(temp130);
  #endif

  return temperature;
}

float get_NTC_resistance(uint16_t NTC_v, uint16_t TH_VDD) {
  uint32_t temp = 10 * TH_VDD;
  float tmp = (float)temp / NTC_v;
  float tmp1 = tmp - 10;

  // Serial1.print("NTC_v: "); Serial1.println(NTC_v);
  // Serial1.print("TH_VDD: "); Serial1.println(TH_VDD);
  // Serial1.print("TH_VDD * 10: "); Serial1.println(temp);
  // Serial1.print("Temp / NTC_v: "); Serial1.println(tmp);
  // Serial1.print("tmp1: "); Serial1.println(tmp1);

  return tmp1;
} 

float get_NTC_temperature(float NTC_resistance) {
  int closest_LUT_index = 0;
  float minDifference = fabs(NTC_Resistance_LUT[0] - NTC_resistance);                              // Found to cause errors if placed in for loop

  for (int i=1; i<194; i++) {
    float difference = fabs(NTC_Resistance_LUT[i] - NTC_resistance);
    if (difference < minDifference) {
      minDifference = difference;
      closest_LUT_index = i;
    }
  }

  return NTC_Temperature_LUT[closest_LUT_index];
}

void obtain_all_NTC_temperatures(float *NTC1_t, float *NTC2_t, float *NTC3_t, float *NTC0_t) {
  /// @section Obtains the NTC voltage measurements from MCP3208 and returns NTC temperature values based on datasheet estimates

  // Check SPI devices before performing readings
  digitalWrite(MAX_CS, HIGH);
  digitalWrite(MCP_CS, LOW);

  digitalWrite(TH_EN, LOW);                                                                        // Enable temperature reading

  SPI.beginTransaction(mcpSettings);

  uint16_t NTC1_v = mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_0));            // NTC1 connected to MCP3208 channel 0
  uint16_t NTC2_v = mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_1));            // NTC2 connected to MCP3208 channel 1
  uint16_t NTC3_v = mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_2));            // NTC3 connected to MCP3208 channel 2
  uint16_t NTC0_v = mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_7));            // NTC0 connected to MCP3208 channel 7
  uint16_t TH_VDD = mcp3208_adc.toAnalog(mcp3208_adc.read(MCP3208::Channel::SINGLE_4));

  SPI.endTransaction();

  digitalWrite(MAX_CS, HIGH);
  digitalWrite(MCP_CS, HIGH);
  digitalWrite(TH_EN, HIGH);                                                                       // Disable temperature reading

  float NTC1_r = get_NTC_resistance(NTC1_v, TH_VDD);
  float NTC2_r = get_NTC_resistance(NTC2_v, TH_VDD);
  float NTC3_r = get_NTC_resistance(NTC3_v, TH_VDD);
  float NTC0_r = get_NTC_resistance(NTC0_v, TH_VDD);

  Serial1.println("NTC readings obtained");
  Serial1.println(NTC1_r);
  Serial1.println(NTC2_r);
  Serial1.println(NTC3_r);
  Serial1.println(NTC0_r);

  Serial1.println("Break\n");

  delay(100);

  *NTC1_t = get_NTC_temperature(NTC1_r);
  *NTC2_t = get_NTC_temperature(NTC2_r);
  *NTC3_t = get_NTC_temperature(NTC3_r);
  *NTC0_t = get_NTC_temperature(NTC0_r);

  Serial1.println("NTC temperatures obtained?\n");
}


//============================================================================================================================================================================
/// @attention ERROR_FN

[[noreturn]] void ErrorFlashes(int number) {
  DEBUG_led_off();
  delay(500);
  while(true) {                                                                                    // Ensure code in this loop is executed in less than 2 seconds to leave 50% headroom for the timer reload
    IWatchdog.reload();

    for(size_t i=0; i<number; i++) {
      DEBUG_led_on();
      delay(220);
      DEBUG_led_off();
      delay(220);
    }
  }
  
  IWatchdog.reload();
  delay(2000);

}

//============================================================================================================================================================================
/// @attention Configuration

void configure_BMS() {
  
  /// @details Provide default values for the cells
  float Calibration = 1.0F;
  uint8_t bypassTemperatureSetPoint = 55;
  uint16_t bypassThresholdmV = 4150;
  uint16_t runaway_CellMinimumVoltage = 3400;
  uint16_t runaway_CellDifferential = 75;

  /// @details Values shared/static between cell instances
  Cell::setCalibration(Calibration);
  Cell::set_bypassTemperatureSetPoint(bypassTemperatureSetPoint);
  Cell::set_bypassThreshold_mV(bypassThresholdmV);
}

//============================================================================================================================================================================

void setup() {
  
  IWatchdog.begin(4000000); // Initialise watchdog with 4 second timeout. Causes a CPU reset if the timer is not reloaded in 4 seconds. 

  pinMode(DISCHARGE_EN, OUTPUT);
  pinMode(MCP_CS, OUTPUT);
  pinMode(MAX_CS, OUTPUT);
  pinMode(PROG1, OUTPUT);
  pinMode(ACT_BAL_CTRL, OUTPUT);
  pinMode(SERVICE_PIN, INPUT);
  pinMode(TH_EN, OUTPUT);
  pinMode(MAX_EN, OUTPUT);
  pinMode(MAX_SAMPLE, OUTPUT);
  pinMode(PROTECT_SIGNAL, OUTPUT);

  // All SPI devices need CS HIGH to be inactive (active low) logic
  // Temperature sensor is LOW due to pmos logic
  // PROTECT_SIGNAL is HIGH to prevent high-side switch from turning on until BMS setup is complete
  
  digitalWrite(DISCHARGE_EN, LOW);
  digitalWrite(MCP_CS, HIGH);
  digitalWrite(MAX_CS, HIGH);
  digitalWrite(PROG1, LOW);
  digitalWrite(ACT_BAL_CTRL, LOW);
  digitalWrite(TH_EN, HIGH);
  digitalWrite(MAX_EN, HIGH);
  digitalWrite(MAX_SAMPLE, LOW);                                                                  // Device in sample phase, low is hold phase?
  digitalWrite(PROTECT_SIGNAL, HIGH); 

  // Use built-in L432KC temperature sensor reading
  ADC_Init();                                                                                      // Use internal ADC for temperature sensor

  Serial1.begin(115200);                                                                           // Use Pins D0 and D1 for UART Debugging (External TTL Required)

  Can1.begin();                                                                                    // Initialise CAN bus
  Can1.setBaudRate(500000);                                                                        // Set CAN bus baud rate to 500 kbit/s

  SPI.begin();

  MAX14920_Configuration();

  // Sometimes MAX reports one more cell than actually connected, so take a few samples and return the lowest cell count
  num_Active_cells = 255;
  for (int i=0; i<4; i++) {
    auto x = MAX14920_AFE_status();

    if (x < num_Active_cells) {
      num_Active_cells = x;
    }
  }

  // Check if at least four cells are connected to ensure there are no UVLO conditions (3 cells leads to inconsistent behaviour, so play safe with 4)
  if(num_Active_cells < 4) {
    ErrorFlashes(3); 
  }

  Wire.begin();
  Wire.setClock(100000);                                                                           // Not all I2C devices support 400kHz, so set to 100kHz 
  
  INA237_setup();

  configure_BMS(); 

  /// @details All SPI devices' CS pin HIGH so inactive

  #ifdef TEST_DEBUG_LED
    // 5 Hz Square-wave triggered timer for testing the Debug LED (if jumper is connected)
    TIM_TypeDef *timer2 = TIM6;                                                                    // General-purpose timer 6
    HardwareTimer *test_Debug_LED = new HardwareTimer(timer2);                                     // Hardware timer object
    test_Debug_LED -> setOverflow(5, HERTZ_FORMAT);                                                // 5 Hz Interrupt
    test_Debug_LED -> attachInterrupt(DEBUG_led_ISR);                                              // Attach the interrupt function
    test_Debug_LED -> resume();                                                                    // Start the timer
  #endif

  #ifdef TEST_HS_PTC
    // 1 Hz Square-wave triggered timer for high-side switch protection
    TIM_TypeDef *timer = TIM2;                                                                     // General-purpose timer 2
    HardwareTimer *test_HS_Protection = new HardwareTimer(timer);                                  // Hardware timer object
    test_HS_Protection -> setOverflow(1, HERTZ_FORMAT);                                            // 1 Hz Interrupt
    test_HS_Protection -> attachInterrupt(HS_Protection_ISR);                                      // Attach the interrupt function
    test_HS_Protection -> resume();                                                                // Start the timer
  #endif

  /*
  
    Write interrupt to sample current from ina237 and compare against threshold for overcurrent faults

    Careful implementation required due to watchdog timer restrictions
  
  */

  digitalWrite(PROTECT_SIGNAL, LOW);                                                               // Set the PROTECT_SIGNAL to LOW to enable the high-side switch

  
}

void loop() { // latest loop, will need modifying to work with new hardware configuration and control scope
  IWatchdog.reload();                                                                              // Ensure contents of loop executed in less than 2 seconds

  /*
    --- INSERT UPDATED TEMPERATURE SENSING CODE HERE ---

    See notes on improving temperature sensing accuracy
  */

  if(cellBalancing !=0) {                                                                          // Switch off any balancing signals before taking voltage readings (leads to loading effect)
    MAX14920_SPI_Command(0, ANALOG_BUFFERED_T1);
    delay(10);
  }

  std::array<uint32_t, 16> rawADC;
  rawADC.fill(0);

  MAX14920_sampleCellVoltage(num_Active_cells, rawADC);                                            // Note: cells read backwards due to MAXIM's logic for addressing the cells

   /*
    --- INSERT UPDATED TEMPERATURE SENSING CODE HERE ---

    See notes on improving temperature sensing accuracy
  */

  /*
  
    Implement logic to determine which temperature sensor has the highest recorded temperature (for the battery pack, not the microcontroller nor ina237)

  */

  /*
  
    Implement Fault protection logic i.e. disconnect the load from the battery if there is overvoltage, overcurrent* or overtemperature.  
  
  */

  /*
  
    Add CAN communication to transmit useful data e.g. voltage, current, temperature, soc, etc. 

    May not be needed but the hardware has been implemented

  */


  // Ensure loop executed within 2 seconds to leave 50% headroom for watchdog timer, otherwise timer can overrun and the microcontroller resets

}



// void loop() { // old loop from prior testings

//   // std::array<uint32_t, 16> rawADC;
//   // rawADC.fill(0);

//   // Serial1.println(MAX14920_AFE_status());
//   // delay(1500);
//   // Serial1.println("Test cell balancing\n");
//   // MAX14920_Test_BAL_output();
//   // // Serial1.println("Sample cell voltage\n");
//   // // MAX14920_sampleCellVoltage(battery_cells_Series, rawADC);
//   // // Serial1.println("Measuring ADC temp\n");

//   // // INA237_currentProtection_test(9);

//   // MCP3208_test_temp();

//   // float NTC1, NTC2, NTC3, NTC0;

//   // Serial1.print("INA temperature: "); Serial1.println(INA237_Temperature());
  
//   // Serial1.println("Obtaining NTC temperatures\n");
//   // obtain_all_NTC_temperatures(&NTC1, &NTC2, &NTC3, &NTC0);

//   // Serial1.print("NTC1 temp: "); Serial1.println(NTC1);
//   // Serial1.print("NTC2 temp: "); Serial1.println(NTC2);
//   // Serial1.print("NTC3 temp: "); Serial1.println(NTC3);
//   // Serial1.print("NTC0 temp: "); Serial1.println(NTC0);



//   // delay(2500);

// }                                                                                