#include <Arduino.h>

class Cell {

    public:
        
        uint16_t getCellVoltage() const {
            return cellVoltage;
        }

        void setCellVoltage(uint16_t v) {
            cellVoltage = v;
        }
        
        static auto getCalibration() {
            return calibration;
        }

        static void setCalibration(float v) {
            calibration = v;
        }

        int16_t getInternalTemperature() const {
            return internalTemperature;
        }

        int16_t getExternalTemperature() const {
            return externalTemperature;
        }

        static bool getOverTemperature() {
            return overtemperature;
        }

        static auto getSafetyTemperatureCutoff() {
            return safetyTemperatureCutoff;                                                        // If exceeded temperature, wait for cooldown
        }

        void setExternalTemperature(int16_t t) {
            externalTemperature = t;
        }

        void setInternalTemperature(int16_t t) {
            internalTemperature = t;
        }

        static void setOverTemperature(bool t) {
            overtemperature = t;
        }

        uint8_t temperatureToByte(int16_t Temp_in_Celcius) const {

            if(Temp_in_Celcius == -999) {
                return 0;                                                                          // No NTC is fitted
            }

            Temp_in_Celcius += 40;                                                                 // Set limits and convert from signed to unsigned
            if(Temp_in_Celcius < 0) {
                Temp_in_Celcius = 1;                                                               // Limit of -39
            }

            else if(Temp_in_Celcius > 255) {
                Temp_in_Celcius = 255;
            }

            return (uint8_t)Temp_in_Celcius;
        }

        uint16_t combineTemperature() const {
            return (uint16_t)(temperatureToByte(getInternalTemperature()) << 8) + temperatureToByte(getExternalTemperature());
        }

        bool bypassCheck() const {
            /// @details returns TRUE if the cell voltage is greater than the @param bypassThreshold_mV
            return (getCellVoltage() > bypassThreshold_mV);
        }

        bool bypassOverheatCheck() const {
            /// @details returns TRUE if the NTC temperature is hotter than the required setting or over the safety limit
            auto temp = getInternalTemperature();
            return (temp > bypassTemperatureSetPoint || temp > Cell::safetyTemperatureCutoff || Cell::getOverTemperature());
        }

        bool bypassActive() const {
            return cell_is_bypassed;
        }

        void startBypass() {
            if(!bypassActive()) {
                cell_is_bypassed = true;                                                           // Record when the bypass started
            }
        }

        void stopBypass() {
            if(!bypassActive())
                return;

            mAhBalanceCounter += 1;                                                                // No accurate way to calculate energy burnt from balancing, so increment counter
            cell_is_bypassed = false;                                                              // to demonstrated cell is balanced
        }

        auto get_mAh_BalanceCounter() const {
            return mAhBalanceCounter;
        }

        void set_mAh_BalanceCounter(float v) {
            mAhBalanceCounter = v;
        }

        static auto get_bypassThreshold_mV() {
            return bypassThreshold_mV;
        }

        static void set_bypassThreshold_mV(uint16_t v) {
            bypassThreshold_mV = v;
        }

        static auto get_bypassTemperatureSetPoint() {
            return bypassTemperatureSetPoint;
        }

        static auto get_bypassTemperatureHysteresis() {
            return bypassTemperatureHysteresis;
        }

        static void set_bypassTemperatureSetPoint(uint16_t v) {
            if (v > Cell::safetyTemperatureCutoff) {
                v = Cell::safetyTemperatureCutoff;
            }
            if (v > 20) {
                bypassTemperatureSetPoint = (uint8_t) v;
                bypassTemperatureHysteresis = (uint8_t) v-5;                                       // Set back hysteresis is set point minus 5 degrees C
            }
        }


    private:
        uint16_t cellVoltage{0};
        int16_t externalTemperature{-999};                                                         // May be ignored
        int16_t internalTemperature{-999};                                                         // May be ignored
        bool cell_is_bypassed{false};
        
        float mAhBalanceCounter{0};

        static const int16_t safetyTemperatureCutoff;                                              // Maximum allowed battery pack temperature before cut off
        static uint8_t bypassTemperatureSetPoint;                                                  // Maximum temperature during balancing
        static uint16_t bypassThreshold_mV;                                                        // Balance over this threshold voltage
        static float calibration;                                                                  // Multiplier for voltage calibration
        static uint8_t bypassTemperatureHysteresis;                                                // Temperature set back when the limit is reached
        static bool overtemperature;                                                               // Cell temperature exceeds bypassTemperatureSetPoint and waiting to drop below bypassTemperatureHysteresis 

};

struct CellModuleConfig {
    uint16_t magicnumber;
    uint16_t sizeof_config;
    uint8_t bypassTemperatureSetPoint;
    uint16_t bypassThreshold_mV;
    float calibration;
    uint16_t run_away_cell_minimumVoltage;
    uint16_t run_away_cell_differential;
} __attribute__((packed));

using CellData = std::array<Cell, 16>;