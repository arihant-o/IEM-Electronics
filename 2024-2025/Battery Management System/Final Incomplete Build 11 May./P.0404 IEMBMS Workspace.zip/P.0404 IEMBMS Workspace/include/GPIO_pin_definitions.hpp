#include <Arduino.h>

/// @brief Defines the GPIO pins, purpose and the nature of the pins

/*

|--------------------------|-------------|----------------|-----------------------------|------------|
| STM32L432KC Hardware Pin | Arduino Pin |      Name      |           Purpose           |   Nature   |
|--------------------------|-------------|----------------|-----------------------------|------------|
| PA9                      | D1          | UART           | Serial Communication, DNU   | Output     |
| PA10                     | D0          | UART           | Serial Communication, DNU   | Input      |
| PA12                     | D2          | CAN TX         | CAN Communication           | Output     |
| PB0                      | D3          | Discharge EN   | Discharge Control           | Output     |
| PB7                      | D4          | I2C SDA        | I2C Data Communication      | In & Out   |
| PB6                      | D5          | I2C SCL        | I2C Clock Communication     | Output     |
| PB1                      | D6          |                |                             |            |
| PA8                      | D9          | MAX_CS         | SPI Chip Select             | Output     |
| PA11                     | D10         | CAN RX         | CAN Communication           | Input      |
| PB5                      | D11         | SPI MOSI       | SPI Data Communication      | Output     |
| PB4                      | D12         | SPI MISO       | SPI Data Communication      | Input      |
| PB3                      | D13         | SPI SCK        | SPI Clock Communication     | Output     |
| PA2                      | A7          | MCP_CS         | SPI Chip Select             | Output     |
| PA7                      | A6          | PROG1          | Programming Signal*         | In & Out   |
| PA6                      | A5          | ACT_BAL_CTRL   | Active Balancing Control    | Output     |
| PA5                      | A4          | SERVICE_PIN    | Service Pin                 | Input      |
| PA4                      | A3          | TH_EN          | Temperature Reading EN      | Output     |
| PA3                      | A2          | MAX_EN         | MAX Chip Enable             | Output     |
| PA1                      | A1          | MAX_SAMPLE     | MAX Chip Sample             | Output     |
| PA0                      | A0          | PROTECT_SIGNAL | Protection Signal           | Output     |
|--------------------------|-------------|----------------|-----------------------------|------------|

*/

const int DISCHARGE_EN = D3;                // Discharge Control Signal for Safety Circuit
const int MAX_CS = D9;                      // SPI Chip Select for MAX14920 chip
const int MCP_CS = A7;                      // SPI Chip Select for MCP3208 chip
const int PROG1 = A6;                       // GPIO pin for detecting balancing module or Debug LED
const int ACT_BAL_CTRL = A5;                // GPIO pin for controlling the active balancing module via PWM
const int SERVICE_PIN = A4;                 // GPIO pin for TCA9555 I2C Expander module
const int TH_EN = A3;                       // GPIO pin for enabling temperature reading via NTC thermistor
const int MAX_EN = A2;                      // EN pin for MAX14920 chip
const int MAX_SAMPLE = A1;                  // SAMPLE pin for MAX14920 chip
const int PROTECT_SIGNAL = A0;              // GPIO pin for controlling the high-side switch for protection