/// @section Idea behind lookup tables for NTCs
/// @details Using the beta relationship forms an exponential curve, where reasonable values are cherry picked and placed into 194 element arrays
/// @details Use MCP2308 to measure the VDD supply of the NTC network and measure the potential divider voltage. Then the NTC resistance can be 
/// @details determined (as an estimate) and round to nearest value in NTC_Resistance LUT. Obtain the index of that element and find the corresponding
/// @details temperature by inserting that index into the NTC_Temperature array. 

/// @note Specific temperatures used as NTCs aren't exact temperature sensors and errors in ADC measurements due to noise and other non-controllable
/// @note factors reduce accuracy. We just need to know when the temperature exceeds a set value e.g. 60C -> 2.5kohms. Higher temperatures produce a
/// @note smaller decay in resistance compared to lower temperatures. The relationship between NTC resistance and temperature is an exponential decay,
/// @note based on the beta model and values provided in the datasheet for the NTCs


const float NTC_Resistance_LUT [194] = {
    108.10, 101.61, 95.56, 89.91, 84.64, 79.71, 75.10, 70.80,
    66.77, 62.99, 59.46, 56.15, 53.05, 50.14, 47.41, 44.85,
    42.44, 40.18, 38.05, 36.05, 34.17, 33.27, 32.40, 31.56,
    30.74, 29.94, 29.17, 28.42, 27.69, 26.98, 26.30, 25.63,
    24.98, 24.35, 23.74, 23.15, 22.57, 22.01, 21.47, 20.94,
    20.42, 19.92, 19.44, 18.96, 18.51, 18.06, 17.62, 17.20,
    16.79, 16.39, 16.00, 15.62, 15.26, 14.90, 14.55, 14.21,
    13.88, 13.56, 13.24, 12.94, 12.64, 12.35, 12.07, 11.80,
    11.53, 11.27, 11.02, 10.77, 10.53, 10.30, 10.07, 9.84,
    9.63, 9.42, 9.21, 9.01, 8.81, 8.62, 8.44, 8.25,
    8.08, 7.90, 7.74, 7.57, 7.41, 7.25, 7.10, 6.95,
    6.81, 6.67, 6.53, 6.39, 6.26, 6.13, 6.01, 5.88,
    5.76, 5.65, 5.53, 5.42, 5.31, 5.20, 5.10, 5.00,
    4.90, 4.80, 4.71, 4.61, 4.52, 4.44, 4.35, 4.26,
    4.18, 4.10, 4.02, 3.94, 3.87, 3.80, 3.72, 3.65,
    3.58, 3.52, 3.45, 3.39, 3.32, 3.26, 3.20, 3.14,
    3.08, 3.03, 2.97, 2.92, 2.86, 2.81, 2.76, 2.71,
    2.66, 2.61, 2.57, 2.52, 2.48, 2.43, 2.39, 2.35,
    2.31, 2.27, 2.23, 2.19, 2.15, 2.11, 2.07, 2.04,
    2.00, 1.97, 1.94, 1.90, 1.87, 1.84, 1.81, 1.78,
    1.75, 1.72, 1.69, 1.66, 1.63, 1.61, 1.58, 1.55,
    1.53, 1.50, 1.48, 1.46, 1.43, 1.41, 1.39, 1.36,
    1.34, 1.32, 1.30, 1.28, 1.26, 1.24, 1.22, 1.20,
    1.18, 1.16, 1.14, 1.13, 1.11, 1.09, 1.08
};

const float NTC_Temperature_LUT [194] = {
    -20.0, -19.0, -18.0, -17.0, -16.0, -15.0, -14.0, -13.0,
    -12.0, -11.0, -10.0, -9.0, -8.0, -7.0, -6.0, -5.0,
    -4.0, -3.0, -2.0, -1.0, 0.0, 0.5, 1.0, 1.5,
    2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5,
    6.0, 6.5, 7.0, 7.5, 8.0, 8.5, 9.0, 9.5,
    10.0, 10.5, 11.0, 11.5, 12.0, 12.5, 13.0, 13.5,
    14.0, 14.5, 15.0, 15.5, 16.0, 16.5, 17.0, 17.5,
    18.0, 18.5, 19.0, 19.5, 20.0, 20.5, 21.0, 21.5,
    22.0, 22.5, 23.0, 23.5, 24.0, 24.5, 25.0, 25.5,
    26.0, 26.5, 27.0, 27.5, 28.0, 28.5, 29.0, 29.5,
    30.0, 30.5, 31.0, 31.5, 32.0, 32.5, 33.0, 33.5,
    34.0, 34.5, 35.0, 35.5, 36.0, 36.5, 37.0, 37.5,
    38.0, 38.5, 39.0, 39.5, 40.0, 40.5, 41.0, 41.5,
    42.0, 42.5, 43.0, 43.5, 44.0, 44.5, 45.0, 45.5,
    46.0, 46.5, 47.0, 47.5, 48.0, 48.5, 49.0, 49.5,
    50.0, 50.5, 51.0, 51.5, 52.0, 52.5, 53.0, 53.5,
    54.0, 54.5, 55.0, 55.5, 56.0, 56.5, 57.0, 57.5,
    58.0, 58.5, 59.0, 59.5, 60.0, 60.5, 61.0, 61.5,
    62.0, 62.5, 63.0, 63.5, 64.0, 64.5, 65.0, 65.5,
    66.0, 66.5, 67.0, 67.5, 68.0, 68.5, 69.0, 69.5,
    70.0, 70.5, 71.0, 71.5, 72.0, 72.5, 73.0, 73.5,
    74.0, 74.5, 75.0, 75.5, 76.0, 76.5, 77.0, 77.5,
    78.0, 78.5, 79.0, 79.5, 80.0, 80.5, 81.0, 81.5,
    82.0, 82.5, 83.0, 83.5, 84.0, 84.5, 85.0
};