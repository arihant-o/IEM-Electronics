#include <Arduino.h>

/// @brief Contains the SPI Configuration/Control bits for the MAX14920
/// @include Contents can also be found in datasheet from pages 18-21
/// @cite https://www.mouser.co.uk/datasheet/2/609/MAX14920_MAX14921-3468632.pdf 

/// @attention MAX14920 Command Bytes

/// Command Byte 1 @details Cell Balancing Signals 
#define AFE_CB1 bit(7)
#define AFE_CB2 bit(6)
#define AFE_CB3 bit(5)
#define AFE_CB4 bit(4)
#define AFE_CB5 bit(3)
#define AFE_CB6 bit(2)
#define AFE_CB7 bit(1)
#define AFE_CB8 bit(0)

/// Command Byte 2 @details Cell Balancing Signals
#define AFE_CB9 bit(7)
#define AFE_CB10 bit(6)
#define AFE_CB11 bit(5)
#define AFE_CB12 bit(4) 
#define AFE_CB13 bit(3)                                                                            // Does not affect MAX14920 operation
#define AFE_CB14 bit(2)                                                                            // Does not affect MAX14920 operation
#define AFE_CB15 bit(1)                                                                            // Does not affect MAX14920 operation
#define AFE_CB16 bit(0)                                                                            // Does not affect MAX14920 operation

// Command Byte 3
#define AFE_ECS bit(7)                                                                             // Enable Cell Selection
#define AFE_SC0 bit(6)                                                                             // Selects the cell for voltage readout during hold phase
#define AFE_SC1 bit(5)
#define AFE_SC2 bit(4)
#define AFE_SC3 bit(3)
#define AFE_SMPLB bit(2)                                                                           // 0: Device in sample phase if SAMPL input is HIGH, 1: Device in hold phase
                                                                                                   /// Not used, so use @param MAX_SAMPLE pin instead
#define AFE_DIAG bit(1)                                                                            // Enable Diagnostics (normally LOW)
#define AFE_LOPW bit(0)                                                                            // Enable Low power mode (normally LOW)


/// @details Cell Selection bits @param SC0, SC1, SC2, SC3
/*
|--------------------------|------------------|------------------|------------------|------------------|
| Cell Selection           | SC3              | SC2              | SC1              | SC0              |
|--------------------------|------------------|------------------|------------------|------------------|
| Cell 1                   | 0                | 0                | 0                | 0                |
| Cell 2                   | 0                | 0                | 0                | 1                |
| Cell 3                   | 0                | 0                | 1                | 0                |
| Cell 4                   | 0                | 0                | 1                | 1                |
| Cell 5                   | 0                | 1                | 0                | 0                |
| Cell 6                   | 0                | 1                | 0                | 1                |
| Cell 7                   | 0                | 1                | 1                | 0                |
| Cell 8                   | 0                | 1                | 1                | 1                |
| Cell 9                   | 1                | 0                | 0                | 0                |
| Cell 10                  | 1                | 0                | 0                | 1                |
| Cell 11                  | 1                | 0                | 1                | 0                |
| Cell 12                  | 1                | 0                | 1                | 1                |
| Cell 13*                 | 1                | 1                | 0                | 0                |
| Cell 14*                 | 1                | 1                | 0                | 1                |
| Cell 15*                 | 1                | 1                | 1                | 0                |
| Cell 16*                 | 1                | 1                | 1                | 1                |
|--------------------------|------------------|------------------|------------------|------------------|

* For MAX14921, does not impact the operation of MAX14920

*/

/// @details Additional ECS and SCx Bit logic @param ECS, SC0, SC1, SC2, SC3
/*

 > 1, X, X, X, X
    Selects the cell for voltage readout during the hold phase. The selected cell voltage is routed to AOUT after the rising /CS edge. Table above demonstrates how to index each cell

 > 0, 0, 0, 0, 0
    AOUT is three-stated and sampling switches are configured for parasitic capacitance error calibration

 > 0, 1, 0, 0, 0
    AOUT is three-state and self calibration of buffer amplifier offset voltage is initiated after the following rising /CS

 > 0, X, X, 0, 1
    Switches the T1, T2 and T3 analog inputs directly to AOUT. Not connected, do not use

 > 0, 0, 0, 1, 1
    Vp/12 voltage is routed to AOUT on the next rising /CS

 > 0, X, X, 1, 1
    Routes and buffers the T1, T2 and T3 to AOUT. Not connected, do not use

*/

/// @details DIAG: 0 Normal Operation, 1 Diagnostic Enable -> 10uA leakage sunk for all CVn inputs

/// @details LOPW: 0 Normal Operation, 1 Low power mode Enable -> Current into LDOIN is reduced to 125uA. Current into Vp reduced to 1uA

#define BUFFER_CALIBRATION AFE_SC0

/// @attention DO NOT USE THREE LINES BELOW
#define ANALOG_BUFFERED_T1 AFE_SC0 | AFE_SC2 | AFE_SC3
#define ANALOG_BUFFERED_T2 AFE_SC1 | AFE_SC2 | AFE_SC3
#define ANALOG_BUFFERED_T3 AFE_SC0 | AFE_SC1 | AFE_SC2 | AFE_SC3

/// @details Cell Selection

#define ANALOG_CELL1 0
#define ANALOG_CELL2 AFE_SC0
#define ANALOG_CELL3 AFE_SC1
#define ANALOG_CELL4 AFE_SC0 | AFE_SC1
#define ANALOG_CELL5 AFE_SC2
#define ANALOG_CELL6 AFE_SC0 | AFE_SC2
#define ANALOG_CELL7 AFE_SC1 | AFE_SC2
#define ANALOG_CELL8 AFE_SC0 | AFE_SC1 | AFE_SC2
#define ANALOG_CELL9 AFE_SC3
#define ANALOG_CELL10 AFE_SC0 | AFE_SC3
#define ANALOG_CELL11 AFE_SC1 | AFE_SC3
#define ANALOG_CELL12 AFE_SC0 | AFE_SC1 | AFE_SC3
#define ANALOG_CELL13 AFE_SC2 | AFE_SC3
#define ANALOG_CELL14 AFE_SC0 | AFE_SC2 | AFE_SC3
#define ANALOG_CELL15 AFE_SC1 | AFE_SC2 | AFE_SC3
#define ANALOG_CELL16 AFE_SC0 | AFE_SC1 | AFE_SC2 | AFE_SC3

/// @details SPI Command to read specific cell voltages

constexpr std::array<uint8_t, 16> CellTable = {
    AFE_ECS | ANALOG_CELL1,
    AFE_ECS | ANALOG_CELL2,
    AFE_ECS | ANALOG_CELL3,
    AFE_ECS | ANALOG_CELL4,
    AFE_ECS | ANALOG_CELL5,
    AFE_ECS | ANALOG_CELL6,
    AFE_ECS | ANALOG_CELL7,
    AFE_ECS | ANALOG_CELL8,
    AFE_ECS | ANALOG_CELL9,
    AFE_ECS | ANALOG_CELL10,
    AFE_ECS | ANALOG_CELL11,
    AFE_ECS | ANALOG_CELL12,
    AFE_ECS | ANALOG_CELL13,
    AFE_ECS | ANALOG_CELL14,
    AFE_ECS | ANALOG_CELL15,
    AFE_ECS | ANALOG_CELL16
};

