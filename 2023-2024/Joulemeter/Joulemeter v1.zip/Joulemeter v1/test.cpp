#include <iostream>
#include <cmath>



float InverseTI_Circuit(float R1, float R2, float R3, float R4, float Vref, float Vout) {
  // manipulation of the TI circuit equation to estimate the input voltage
  
  float Vin, temp;
  Vout = Vout + Vref*(R1/R2);
  temp = (R4/(R3+R4))*((R1+R2)/R2);
  Vin = Vout/temp;

  return Vin;
}

int main() {
    float DAC_Vref = 1.5;
    float sim_Vref = 2.5;
    float sim_Vout = 4.95;
    float vR1=1000,vR2=777,vR3=402,vR4=1000; // voltage TI circuit resistors
    float cR1=0,cR2=0,cR3=0,cR4=0; // current TI circuit resistors

    //std::cout << InverseTI_Circuit(vR1,vR2,vR3,vR4,sim_Vref,sim_Vout) << "\n";
    float dacvalue = ((DAC_Vref/3.3)*256)-1;
    dacvalue = std::round(dacvalue);
    std::cout << dacvalue << "\n";



}